# Phase 2: Clone & Deploy

Clone the inspiration site exactly, apply brand basics, deploy to Vercel.

---

## Part 1: Site Analysis

### 1.1 Analyze the Inspiration URL

Try WebFetch first. If blocked or incomplete, use `browser_subagent`:

```
browser_subagent(
  Task: "Navigate to [URL]. Take full-page screenshots.
         Scroll the entire page, screenshot each section.
         Extract: exact colors (hex), fonts, layout structure, spacing,
         section order, animations, hover effects, nav style, CTA style,
         unique UI elements, background treatment, image usage, decorative elements.",
  RecordingName: "inspiration_analysis"
)
```

### 1.2 Extraction Checklist

Document every detail:

```
CLONE EXTRACTION: [URL]

SECTIONS (in order):
1. [Section type] — [brief description of content and layout]
2. [Section type] — [brief description]
...

COLORS:
- Background: [hex]
- Text primary: [hex]
- Text secondary: [hex]
- Accent/CTA: [hex]
- Section alternation pattern: [e.g., white → light gray → white]

TYPOGRAPHY:
- Heading font: [name, weight, size range, case, letter-spacing]
- Body font: [name, weight, size]
- Special text treatments: [e.g., uppercase badges, serif quotes]

LAYOUT:
- Container width: [wide/narrow/full-bleed]
- Grid style: [centered, bento, asymmetric, editorial]
- Spacing density: [tight/normal/generous]
- Image usage: [heavy/moderate/minimal]

NAV:
- Style: [standard links / hamburger / minimal "Menu+" / sticky / transparent]

HERO:
- Pattern: [centered text / split image+text / full-screen image / video]
- Special elements: [avatar stack, star ratings, floating badges, etc.]

UNIQUE UI PATTERNS:
- [List every distinctive visual element: pill buttons with icons, bento grids,
  avatar stacks, editorial typography, floating cards, gradient meshes, etc.]

ANIMATIONS:
- Page load: [what happens]
- Scroll: [reveal style]
- Hover: [card/button behavior]
```

---

## Part 2: Project Setup

### 2.1 Initialize Next.js + shadcn/ui

```bash
npx -y create-next-app@latest [project-name] --typescript --tailwind --eslint
# Select: Yes (src dir), Yes (App Router), No (Turbo)

cd [project-name]

# Essential libraries
npm install framer-motion lucide-react clsx tailwind-merge

# Initialize shadcn/ui (New York style, Neutral base, CSS variables: yes)
npx shadcn@latest init -d

# Core components
npx shadcn@latest add button card badge accordion tabs input separator avatar
```

### 2.2 Configure Preview Mode

Create `.claude/launch.json` in the project root:

```json
{
  "version": "0.0.1",
  "configurations": [
    {
      "name": "website-preview",
      "runtimeExecutable": "npm",
      "runtimeArgs": ["run", "dev"],
      "port": 3000,
      "autoPort": true
    }
  ]
}
```

### 2.3 Folder Structure

```
src/
├── app/
│   ├── layout.tsx       # Root layout with fonts, metadata
│   ├── page.tsx         # Landing page assembling all sections
│   └── globals.css      # CSS variables from extraction
├── components/
│   ├── ui/              # shadcn primitives (Button, Card, etc.)
│   ├── sections/        # Cloned sections (Hero, Features, etc.)
│   └── layout/          # Navbar, Footer, SectionWrapper
└── lib/
    └── utils.ts         # cn() utility
```

---

## Part 3: Clone Process

### 3.1 Design System from Extraction

Map extracted colors to shadcn CSS variables in `globals.css`:

```css
@layer base {
  :root {
    --background: [extracted bg → HSL];
    --foreground: [extracted text → HSL];
    --primary: [extracted accent → HSL];
    --primary-foreground: [computed for contrast];
    --secondary: [extracted secondary → HSL];
    --muted: [section alternation color → HSL];
    --muted-foreground: [subdued text → HSL];
    --card: [card bg → HSL];
    --border: [border color → HSL];
    --ring: [focus ring → HSL];
    --radius: [match inspiration: 0 for sharp, 0.5rem for soft, 9999px for pill];
  }
}
```

Import extracted fonts via `next/font/google` in `layout.tsx`.

### 3.2 Section-by-Section Reproduction

For EACH section from the extraction:

1. **Match the layout exactly** — if the inspiration has a split hero with image right, build that
2. **Match typography** — same font sizes, weights, cases, spacing
3. **Match colors** — exact hex values from extraction
4. **Match spacing** — padding, margins, gaps that mirror the inspiration
5. **Keep the inspiration's copy temporarily** — it will be replaced in Phase 4
6. **Reproduce unique UI patterns** — pill buttons, avatar stacks, bento grids, floating elements
7. **Generate images with Nano Banana** — see Part 3.5 below

### 3.3 Rules

- **DO NOT use the component library during cloning.** Build from scratch to match the inspiration exactly.
- **DO NOT invent design elements.** Only reproduce what exists on the inspiration site.
- **DO NOT substitute** — if the inspiration has a bento grid, don't replace it with a standard grid.
- **DO match hover states and animations** observed during extraction.
- **DO NOT use placeholder images.** Generate real images with Nano Banana MCP (see Part 3.5).

### 3.4 Image Extraction from Inspiration

During the extraction (Part 1), catalog every image on the inspiration site:

```
IMAGES:
1. Hero — [description: e.g., "abstract gradient mesh behind product mockup, purple-blue tones"]
2. Features — [e.g., "3 isometric device mockups showing app screens"]
3. About — [e.g., "team photo placeholder, dark overlay"]
...
```

Note the **style** (abstract/geometric/mockup/illustration), **dimensions** (landscape/square/portrait), **color palette**, and **visual role** (decorative background, product showcase, proof element).

### 3.5 Image Generation with Nano Banana MCP

Generate images for the cloned site using the `generate_image` MCP tool. This replaces placeholder images with real, on-brand visuals.

**Tool:** `generate_image` (from Nano Banana MCP)

**Parameters:**
- `prompt` — Detailed description of the image
- `aspectRatio` — Match the inspiration's image dimensions: `"16:9"` (hero banners), `"1:1"` (cards), `"4:3"` (features), `"3:2"` (landscapes)

**Prompt structure for website images:**
```
[Style reference]: Clean, modern [style] image in the style of [inspiration site vibe].
[Subject]: [What the image shows — abstract gradient, product mockup, geometric pattern, etc.]
[Colors]: Using brand colors [hex values from extraction].
[Composition]: [Layout — centered, floating, isometric, etc.]
[Mood]: [Professional/bold/minimal/warm — match the site's tone.]
Aspect ratio: [ratio].
No text. No watermarks. Clean background.
```

**Rules:**
1. **Never generate human faces** — use abstract/geometric visuals, product mockups, or illustrations
2. **Match the inspiration's image style** — if it uses gradient meshes, generate gradient meshes. If it uses isometric mockups, generate those.
3. **Use extracted brand colors** in the prompt
4. **Generate at the right aspect ratio** — must match where the image will be placed
5. **Save to project:** Copy from `./generated_imgs/` to `public/images/` in the Next.js project
6. **Reference with next/image:** `<Image src="/images/hero-bg.png" alt="..." width={} height={} />`

**Typical images to generate (5-10 per site):**

| Location | Typical Style | Aspect Ratio |
|----------|--------------|-------------|
| Hero background | Abstract gradient mesh, geometric pattern | `16:9` or `3:2` |
| Hero product visual | Device mockup, app screenshot, floating UI | `4:3` or `1:1` |
| Feature icons/illustrations | Simple geometric illustrations | `1:1` |
| About/team section | Abstract workspace, geometric pattern | `16:9` |
| CTA background | Gradient, mesh, or pattern | `16:9` |

**If Nano Banana MCP is not available:** Fall back to CSS-only visuals (gradient backgrounds, geometric shapes with Tailwind, SVG patterns). Never leave broken image placeholders.

---

## Part 4: Brand Application

If the user provided brand assets in Q10:

1. **Logo** — Replace the inspiration's logo with the user's
2. **Brand colors** — If "close match", keep the inspiration's palette. If user has specific colors, replace the accent/primary color only, keeping the inspiration's color relationships intact.
3. **Fonts** — Keep the inspiration's fonts unless the user specified brand fonts

If Q9 was "Just inspiration" (not close match):
- More freedom to adjust colors to match user's brand
- Keep the layout and structure from inspiration but adapt visual style

---

## Part 5: Preview & Deploy

### 5.1 Build & Lint

```bash
npm run lint -- --fix
npm run build
```

Fix any build errors before proceeding.

### 5.2 Deploy to Vercel

Deploy FIRST — the Vercel URL is the primary preview.

```bash
npx vercel login
npx vercel
```

This gives you a preview URL (e.g., `https://project-xyz.vercel.app`).

### 5.3 Open Preview in Claude Desktop

**Claude Desktop users:** The embedded preview panel auto-starts the local dev server from `.claude/launch.json`. This gives the user an interactive preview directly inside Claude Desktop.

The preview panel supports **element selection** — the user can click any element directly in the preview, and its DOM metadata (CSS selector, HTML tag, text content, source file location) is automatically injected into the chat context. This makes iteration precise: the user clicks a heading, types "make this bolder", and you know exactly which element to change.

**CLI users:** Start the dev server manually: `npm run dev &` then `open http://localhost:3000`.

### 5.4 Present Both URLs

Always give the user BOTH the live Vercel URL and the local preview:

```
Your cloned site is live! I've set up two ways to view it:

VERCEL (shareable): [vercel preview URL]
LOCAL PREVIEW: Open in the preview panel to the right →

The preview panel lets you click any element directly to request changes.

Take a look and let me know:
1. Does this match the inspiration site's look and feel?
2. Anything off with layout, spacing, or typography?

Once you're happy with the clone, I'll ask you deeper questions about your
business so we can replace the copy with YOUR content.
```

### 5.5 Preview Checklist

Verify against `references/05-quality-rules.md`:
- [ ] All sections render without errors
- [ ] Layout matches inspiration site
- [ ] Typography matches (fonts, sizes, weights)
- [ ] Colors match extraction
- [ ] Images generated and loading correctly
- [ ] Animations/hover states work
- [ ] Mobile responsive
- [ ] No console errors

### 5.6 Iteration on Clone Fidelity

During iteration, changes hot-reload in the Claude Desktop preview panel instantly. The user can:
- **Click elements** in the preview to reference them in chat
- **Resize the preview** to test responsive behavior
- **Compare** by opening the Vercel URL alongside the original inspiration in a browser

After each round of changes, re-deploy to Vercel: `npx vercel`

Iterate until the user confirms the clone matches. Then proceed to Phase 3.
