{
  "tasksFolder": "TaskNotes/Tasks",
  "moveArchivedTasks": false,
  "archiveFolder": "TaskNotes/Archive",
  "taskTag": "task",
  "taskIdentificationMethod": "tag",
  "hideIdentifyingTagsInCards": false,
  "taskPropertyName": "",
  "taskPropertyValue": "",
  "excludedFolders": "",
  "defaultTaskPriority": "normal",
  "defaultTaskStatus": "open",
  "taskOrgFiltersCollapsed": false,
  "taskFilenameFormat": "zettel",
  "storeTitleInFilename": true,
  "customFilenameTemplate": "{title}",
  "taskCreationDefaults": {
    "defaultContexts": "",
    "defaultTags": "",
    "defaultProjects": "",
    "useParentNoteAsProject": false,
    "defaultTimeEstimate": 0,
    "defaultRecurrence": "none",
    "defaultDueDate": "none",
    "defaultScheduledDate": "today",
    "bodyTemplate": "",
    "useBodyTemplate": false,
    "defaultReminders": []
  },
  "calendarViewSettings": {
    "defaultView": "dayGridMonth",
    "customDayCount": 3,
    "slotDuration": "00:30:00",
    "slotMinTime": "00:00:00",
    "slotMaxTime": "24:00:00",
    "scrollTime": "08:00:00",
    "firstDay": 1,
    "timeFormat": "24",
    "showWeekends": true,
    "locale": "",
    "defaultShowScheduled": true,
    "defaultShowDue": true,
    "defaultShowDueWhenScheduled": true,
    "defaultShowScheduledToDueSpan": false,
    "defaultShowTimeEntries": false,
    "defaultShowRecurring": true,
    "defaultShowICSEvents": true,
    "enableTimeblocking": false,
    "defaultShowTimeblocks": true,
    "defaultTimeblockColor": "#6366f1",
    "nowIndicator": true,
    "selectMirror": true,
    "weekNumbers": false,
    "showTodayHighlight": true,
    "eventMinHeight": 15,
    "slotEventOverlap": true,
    "eventMaxStack": null,
    "dayMaxEvents": true,
    "dayMaxEventRows": false
  },
  "pomodoroWorkDuration": 25,
  "pomodoroShortBreakDuration": 5,
  "pomodoroLongBreakDuration": 15,
  "pomodoroLongBreakInterval": 4,
  "pomodoroAutoStartBreaks": true,
  "pomodoroAutoStartWork": false,
  "pomodoroNotifications": true,
  "pomodoroSoundEnabled": true,
  "pomodoroSoundVolume": 50,
  "pomodoroStorageLocation": "plugin",
  "pomodoroMobileSidebar": "tab",
  "enableTaskLinkOverlay": true,
  "disableOverlayOnAlias": false,
  "enableInstantTaskConvert": true,
  "useDefaultsOnInstantConvert": true,
  "enableNaturalLanguageInput": true,
  "nlpDefaultToScheduled": true,
  "nlpLanguage": "en",
  "uiLanguage": "system",
  "statusSuggestionTrigger": "*",
  "nlpTriggers": {
    "triggers": [
      {
        "propertyId": "tags",
        "trigger": "#",
        "enabled": true
      },
      {
        "propertyId": "contexts",
        "trigger": "@",
        "enabled": true
      },
      {
        "propertyId": "projects",
        "trigger": "+",
        "enabled": true
      },
      {
        "propertyId": "status",
        "trigger": "*",
        "enabled": true
      },
      {
        "propertyId": "priority",
        "trigger": "!",
        "enabled": false
      }
    ]
  },
  "singleClickAction": "edit",
  "doubleClickAction": "openNote",
  "projectAutosuggest": {
    "enableFuzzy": false,
    "rows": [
      "{title|n(Title)}",
      "{aliases|n(Aliases)}",
      "{file.path|n(Path)}"
    ],
    "showAdvanced": false,
    "requiredTags": [],
    "includeFolders": [],
    "propertyKey": "",
    "propertyValue": ""
  },
  "inlineTaskConvertFolder": "{{currentNotePath}}",
  "disableNoteIndexing": false,
  "suggestionDebounceMs": 0,
  "fieldMapping": {
    "title": "title",
    "status": "status",
    "priority": "priority",
    "due": "due",
    "scheduled": "scheduled",
    "contexts": "contexts",
    "projects": "projects",
    "timeEstimate": "timeEstimate",
    "completedDate": "completedDate",
    "dateCreated": "dateCreated",
    "dateModified": "dateModified",
    "recurrence": "recurrence",
    "recurrenceAnchor": "recurrence_anchor",
    "archiveTag": "archived",
    "timeEntries": "timeEntries",
    "completeInstances": "complete_instances",
    "skippedInstances": "skipped_instances",
    "blockedBy": "blockedBy",
    "pomodoros": "pomodoros",
    "icsEventId": "icsEventId",
    "icsEventTag": "ics_event",
    "reminders": "reminders"
  },
  "customStatuses": [
    {
      "id": "none",
      "value": "none",
      "label": "None",
      "color": "#cccccc",
      "isCompleted": false,
      "order": 0,
      "autoArchive": false,
      "autoArchiveDelay": 5
    },
    {
      "id": "open",
      "value": "open",
      "label": "Open",
      "color": "#808080",
      "isCompleted": false,
      "order": 1,
      "autoArchive": false,
      "autoArchiveDelay": 5
    },
    {
      "id": "in-progress",
      "value": "in-progress",
      "label": "In progress",
      "color": "#0066cc",
      "isCompleted": false,
      "order": 2,
      "autoArchive": false,
      "autoArchiveDelay": 5
    },
    {
      "id": "done",
      "value": "done",
      "label": "Done",
      "color": "#00aa00",
      "isCompleted": true,
      "order": 3,
      "autoArchive": false,
      "autoArchiveDelay": 5
    }
  ],
  "customPriorities": [
    {
      "id": "none",
      "value": "none",
      "label": "None",
      "color": "#cccccc",
      "weight": 0
    },
    {
      "id": "low",
      "value": "low",
      "label": "Low",
      "color": "#00aa00",
      "weight": 1
    },
    {
      "id": "normal",
      "value": "normal",
      "label": "Normal",
      "color": "#ffaa00",
      "weight": 2
    },
    {
      "id": "high",
      "value": "high",
      "label": "High",
      "color": "#ff0000",
      "weight": 3
    }
  ],
  "showReleaseNotesOnUpdate": true,
  "showTrackedTasksInStatusBar": false,
  "autoStopTimeTrackingOnComplete": true,
  "autoStopTimeTrackingNotification": false,
  "showRelationships": true,
  "relationshipsPosition": "bottom",
  "showTaskCardInNote": true,
  "showExpandableSubtasks": true,
  "subtaskChevronPosition": "right",
  "viewsButtonAlignment": "right",
  "hideCompletedFromOverdue": true,
  "savedViews": [],
  "enableNotifications": true,
  "notificationType": "system",
  "enableAPI": true,
  "apiPort": 8080,
  "apiAuthToken": "",
  "enableMCP": false,
  "webhooks": [],
  "userFields": [],
  "enableModalSplitLayout": true,
  "defaultVisibleProperties": [
    "status",
    "priority",
    "due",
    "scheduled",
    "projects",
    "contexts",
    "tags",
    "blocked",
    "blocking"
  ],
  "inlineVisibleProperties": [
    "status",
    "priority",
    "due",
    "scheduled",
    "recurrence"
  ],
  "enableBases": true,
  "enableMdbaseSpec": false,
  "autoCreateDefaultBasesFiles": true,
  "commandFileMapping": {
    "open-calendar-view": "TaskNotes/Views/mini-calendar-default.base",
    "open-kanban-view": "TaskNotes/Views/kanban-default.base",
    "open-tasks-view": "TaskNotes/Views/tasks-default.base",
    "open-advanced-calendar-view": "TaskNotes/Views/calendar-default.base",
    "open-agenda-view": "TaskNotes/Views/agenda-default.base",
    "relationships": "TaskNotes/Views/relationships.base"
  },
  "modalFieldsConfig": {
    "version": 1,
    "fields": [
      {
        "id": "title",
        "fieldType": "core",
        "group": "basic",
        "displayName": "Title",
        "visibleInCreation": true,
        "visibleInEdit": true,
        "order": 0,
        "enabled": true,
        "required": true
      },
      {
        "id": "details",
        "fieldType": "core",
        "group": "basic",
        "displayName": "Details",
        "visibleInCreation": true,
        "visibleInEdit": true,
        "order": 1,
        "enabled": true
      },
      {
        "id": "contexts",
        "fieldType": "core",
        "group": "metadata",
        "displayName": "Contexts",
        "visibleInCreation": true,
        "visibleInEdit": true,
        "order": 0,
        "enabled": true
      },
      {
        "id": "tags",
        "fieldType": "core",
        "group": "metadata",
        "displayName": "Tags",
        "visibleInCreation": true,
        "visibleInEdit": true,
        "order": 1,
        "enabled": true
      },
      {
        "id": "time-estimate",
        "fieldType": "core",
        "group": "metadata",
        "displayName": "Time Estimate",
        "visibleInCreation": true,
        "visibleInEdit": true,
        "order": 2,
        "enabled": true
      },
      {
        "id": "projects",
        "fieldType": "organization",
        "group": "organization",
        "displayName": "Projects",
        "visibleInCreation": true,
        "visibleInEdit": true,
        "order": 0,
        "enabled": true
      },
      {
        "id": "subtasks",
        "fieldType": "organization",
        "group": "organization",
        "displayName": "Subtasks",
        "visibleInCreation": true,
        "visibleInEdit": true,
        "order": 1,
        "enabled": true
      },
      {
        "id": "blocked-by",
        "fieldType": "dependency",
        "group": "dependencies",
        "displayName": "Blocked By",
        "visibleInCreation": true,
        "visibleInEdit": true,
        "order": 0,
        "enabled": true
      },
      {
        "id": "blocking",
        "fieldType": "dependency",
        "group": "dependencies",
        "displayName": "Blocking",
        "visibleInCreation": true,
        "visibleInEdit": true,
        "order": 1,
        "enabled": true
      }
    ],
    "groups": [
      {
        "id": "basic",
        "displayName": "Basic Information",
        "order": 0,
        "collapsible": false,
        "defaultCollapsed": false
      },
      {
        "id": "metadata",
        "displayName": "Metadata",
        "order": 1,
        "collapsible": true,
        "defaultCollapsed": false
      },
      {
        "id": "organization",
        "displayName": "Organization",
        "order": 2,
        "collapsible": true,
        "defaultCollapsed": false
      },
      {
        "id": "dependencies",
        "displayName": "Dependencies",
        "order": 3,
        "collapsible": true,
        "defaultCollapsed": false
      },
      {
        "id": "custom",
        "displayName": "Custom Fields",
        "order": 4,
        "collapsible": true,
        "defaultCollapsed": false
      }
    ]
  }
}
