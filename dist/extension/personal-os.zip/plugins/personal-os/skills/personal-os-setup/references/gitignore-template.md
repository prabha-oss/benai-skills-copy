# OS files
.DS_Store
Thumbs.db

# Obsidian workspace (changes per machine)
.obsidian/workspace.json
.obsidian/workspace-mobile.json

# Obsidian plugin binaries (users install via Obsidian community plugins)
.obsidian/plugins/*/main.js
.obsidian/plugins/*/styles.css
.obsidian/themes/*/theme.css

# Environment and secrets
.env
.env.*
*.key
*.pem

# Private user content (never commit to public repo)
Meetings/team-standups/*.md
Meetings/client-calls/*.md
Meetings/one-on-ones/*.md
Meetings/general/*.md
Daily/*.md
.claude/context/memory/
.claude/context/session-logs/
.claude/context/projects/*.md
!.claude/context/projects/CLAUDE.md

# Private folders (uncomment if you use them)
# private/
# journal/
# finance/
# health/

# Node modules (if using any scripts)
node_modules/

# Logs
*.log
